#!/usr/bin/python 
  
import socket 
import threading 
import P2S
 
class ClientHandler(threading.Thread): 
 
    def __init__(self, client,rfcDic,peers): 
        self.myrfs = []
        threading.Thread.__init__(self) 
        self.client_sock, self.client_addr = client
        self.client=client
        self.rfcDic=rfcDic 
        self.peersDic=peers
        self.Hostname=""
        self.rfcList=[]
        return
    
    def removeIPfromPeerList(self):
        if self.client in self.peersDic:
            del self.peersDic[self.client]
        #print "Current Peer List after connection is closed:"
        #print self.peersDic
        return
    
    def removeRFCitem(self):
        for rfcnum in self.rfcList:
            #print rfcnum
            for li in self.rfcDic[rfcnum]:
                if self.Hostname in li:
                    self.rfcDic[rfcnum].remove(li)
                    if self.rfcDic[rfcnum] == []:
                        self.rfcDic.pop(rfcnum)
                    
                
    
    def decodeADD(self,dataDic):
        rfcNum=0
        rfcNum=dataDic['ADD'][1]
        version=dataDic['ADD'][2]
        self.Hostname= dataDic['Host:']
        port=int(dataDic['Port:'])
        Title=dataDic['Title:']
        if( port <0 or port > 65535  or rfcNum==0 or dataDic['ADD'][0]!="RFC" ):
            self.sendBadresponse()
            return
        elif version!= "P2P-CI/1.0":
            self.sendInvalidVersion()
            return
        else:
            self.rfcList.append(rfcNum)
            if (self.rfcDic.has_key(rfcNum) == False):
                self.rfcDic[rfcNum]=[ [rfcNum,Title,self.Hostname,port]] 
            else:
                lis=self.rfcDic[rfcNum]
                dup=False
                for rfc,tit,host,po in lis:
                    if (rfc==rfcNum and tit==Title and host==self.Hostname and po==port):
                        dup=True
                        break
                if dup==False:
                    lis.insert(0,[rfcNum,Title,self.Hostname,port])           
            print self.rfcDic
            self.sendADDResponse()                
            return
            
    
    def decodeLOOKUP(self,dataDic):
        rfcNum=0
        rfcNum=dataDic['LOOKUP'][1]
        version=dataDic['LOOKUP'][2]
        
        self.Hostname= dataDic['Host:']
        port=int(dataDic['Port:'])
        Title=""
        Title=dataDic['Title:']
        if( port <0 or port > 65535  or rfcNum==0 or dataDic['LOOKUP'][0]!="RFC" or Title==""):
            self.sendBadresponse()
            return
        elif version!= "P2P-CI/1.0":
            self.sendInvalidVersion()
            return
        else:
            if (self.rfcDic.has_key(rfcNum) == False):
                self.sendNotFound()
            else:
                print self.rfcDic[rfcNum]
                self.sendLOOKUPResponse(self.rfcDic[rfcNum])                
            return
    
    
    def decodeLISTALL(self,dataDic):
        version=dataDic['LIST'][1]
        
        self.Hostname= dataDic['Host:']
        port=int(dataDic['Port:'])
        if( port <0 or port > 65535  or dataDic['LIST'][0]!="ALL" or version!= "P2P-CI/1.0" ):
            self.sendBadresponse()
            return
        elif version!= "P2P-CI/1.0":
            self.sendInvalidVersion()
            return
        else:
            li=[]
            for key in self.rfcDic:
                for rfcn,title,hostname,port in self.rfcDic[key]:
                    li.append([rfcn,title,hostname,port])
            print li
            self.sendLOOKUPResponse(li)                
            return
    
    
    def sendLOOKUPResponse(self,li):
        data=P2S.response(200,li)
        self.client_sock.sendall(data)
        return
    
    def sendADDResponse(self):
        data=P2S.response(200,'null')
        self.client_sock.sendall(data)
        return
    
    def sendBadresponse(self):
        data=P2S.response(400,'null')
        self.client_sock.sendall(data)
        return
    
    def sendNotFound(self):
        data=P2S.response(404,'null')
        self.client_sock.sendall(data)
        return
    
    def sendInvalidVersion(self):
        data=P2S.response(505,'null')
        self.client_sock.sendall(data)
        return
    
    def run(self):
        print "Got connection"
        while True:
            data = self.client_sock.recv(1024)
            print "Data from the user"
            print data
            if data:
                linesDic=P2S.decodeHeader(data)
                if linesDic:
                    self.peersDic[self.client]= [linesDic['Host:'],linesDic['Port:']]
                    print "Peers Dectionary"
                    print self.peersDic
                    if(linesDic.has_key('ADD') != False):
                        print "Calling ADD response"
                        self.decodeADD(linesDic)
                        
                    elif( (linesDic.has_key('LOOKUP') != False)  ):
                        print "Calling LOOKUP response"
                        self.decodeLOOKUP(linesDic)
                        
                    elif( (linesDic.has_key('LIST') != False) ):
                        print "Calling LIST response"
                        self.decodeLISTALL(linesDic)
                        
                    else:
                        self.sendBadresponse()
            else:    
                print "Closing connection"
                self.client_sock.close()
                self.removeRFCitem()
                print (self.rfcDic)
                self.removeIPfromPeerList()
                print self.peersDic
                break  
                
                return




class CentralServer:
    
    def __init__(self,p):
        self.peersdic={}
        self.port=p
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
        self.bind()        
        self.RFCdic={}
    
    def bind(self):
        self.sock.bind((socket.gethostname(), self.port)) 
        self.sock.listen(0) 
        print "Waiting_for_clients_..." 

    def accept(self): 
        client = self.sock.accept()
        self.Ch=ClientHandler(client,self.RFCdic,self.peersdic)
        self.Ch.start()
        
 

def main():
    cs=CentralServer(7734)
    while(True):
        cs.accept()

if __name__ == "__main__":
    main()
